import 'reflect-metadata';
import { NestFactory } from '@nestjs/core';
import { SwaggerModule, DocumentBuilder } from '@nestjs/swagger';
import { Module, Controller, Get } from '@nestjs/common';

@Controller()
class AppController {
  @Get() getHello() { return { message: 'Patent API', version: '1.0' }; }
  @Get('health') health() { return { status: 'healthy' }; }
}

@Module({ controllers: [AppController] })
class AppModule {}

async function bootstrap() {
  const app = await NestFactory.create(AppModule);
  app.enableCors();
  const config = new DocumentBuilder().setTitle('Patent API').setVersion('1.0').build();
  const document = SwaggerModule.createDocument(app, config);
  SwaggerModule.setup('api/docs', app, document);
  await app.listen(3001);
  console.log('API at http://localhost:3001/api/docs');
}
bootstrap();
