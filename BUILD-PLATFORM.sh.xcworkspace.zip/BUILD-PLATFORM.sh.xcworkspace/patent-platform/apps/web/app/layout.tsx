export default function RootLayout({ children }: { children: React.ReactNode }) {
  return (
    <html lang="en">
      <body>
        <div style={{ background: '#fef3c7', padding: '10px', textAlign: 'center', fontWeight: 'bold' }}>
          ⚖️ Not legal advice. Consult a patent practitioner.
        </div>
        {children}
      </body>
    </html>
  );
}
