export default function HomePage() {
  return (
    <div style={{ padding: '40px', fontFamily: 'system-ui' }}>
      <h1>🚀 Patent Filing Platform</h1>
      <p>AI-powered patent drafting system</p>
      <div style={{ marginTop: '20px' }}>
        <h3>Quick Links:</h3>
        <p>📚 API: <a href="http://localhost:3001/api/docs">localhost:3001/api/docs</a></p>
        <p>�� Agent: <a href="http://localhost:8000/docs">localhost:8000/docs</a></p>
      </div>
    </div>
  );
}
