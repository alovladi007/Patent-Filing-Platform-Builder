#!/bin/bash

echo "🚀 Building Patent Filing Platform..."

# Create project
mkdir -p patent-platform && cd patent-platform

# Create structure
mkdir -p apps/web/app apps/api/src services/agent/app infra/docker

# Create Next.js app
cat > apps/web/package.json << 'EOF'
{
  "name": "@apps/web",
  "scripts": {
    "dev": "next dev",
    "build": "next build",
    "start": "next start"
  },
  "dependencies": {
    "next": "14.0.4",
    "react": "^18.2.0",
    "react-dom": "^18.2.0"
  }
}
EOF

cat > apps/web/next.config.js << 'EOF'
module.exports = { reactStrictMode: true }
EOF

cat > apps/web/app/layout.tsx << 'EOF'
export default function RootLayout({ children }: { children: React.ReactNode }) {
  return (
    <html lang="en">
      <body>
        <div style={{ background: '#fef3c7', padding: '10px', textAlign: 'center', fontWeight: 'bold' }}>
          ⚖️ Not legal advice. Consult a patent practitioner.
        </div>
        {children}
      </body>
    </html>
  );
}
EOF

cat > apps/web/app/page.tsx << 'EOF'
export default function HomePage() {
  return (
    <div style={{ padding: '40px', fontFamily: 'system-ui' }}>
      <h1>🚀 Patent Filing Platform</h1>
      <p>AI-powered patent drafting system</p>
      <div style={{ marginTop: '20px' }}>
        <h3>Quick Links:</h3>
        <p>📚 API: <a href="http://localhost:3001/api/docs">localhost:3001/api/docs</a></p>
        <p>�� Agent: <a href="http://localhost:8000/docs">localhost:8000/docs</a></p>
      </div>
    </div>
  );
}
EOF

# Create API
cat > apps/api/package.json << 'EOF'
{
  "name": "@apps/api",
  "scripts": {"dev": "ts-node src/main.ts"},
  "dependencies": {
    "@nestjs/common": "^10.3.0",
    "@nestjs/core": "^10.3.0",
    "@nestjs/platform-express": "^10.3.0",
    "@nestjs/swagger": "^7.1.17",
    "reflect-metadata": "^0.2.1",
    "rxjs": "^7.8.1"
  },
  "devDependencies": {
    "ts-node": "^10.9.2",
    "typescript": "^5.3.3",
    "@types/node": "^20.10.6"
  }
}
EOF

cat > apps/api/tsconfig.json << 'EOF'
{
  "compilerOptions": {
    "module": "commonjs",
    "target": "ES2021",
    "experimentalDecorators": true,
    "emitDecoratorMetadata": true,
    "strict": false
  }
}
EOF

cat > apps/api/src/main.ts << 'EOF'
import 'reflect-metadata';
import { NestFactory } from '@nestjs/core';
import { SwaggerModule, DocumentBuilder } from '@nestjs/swagger';
import { Module, Controller, Get } from '@nestjs/common';

@Controller()
class AppController {
  @Get() getHello() { return { message: 'Patent API', version: '1.0' }; }
  @Get('health') health() { return { status: 'healthy' }; }
}

@Module({ controllers: [AppController] })
class AppModule {}

async function bootstrap() {
  const app = await NestFactory.create(AppModule);
  app.enableCors();
  const config = new DocumentBuilder().setTitle('Patent API').setVersion('1.0').build();
  const document = SwaggerModule.createDocument(app, config);
  SwaggerModule.setup('api/docs', app, document);
  await app.listen(3001);
  console.log('API at http://localhost:3001/api/docs');
}
bootstrap();
EOF

# Create Agent
cat > services/agent/requirements.txt << 'EOF'
fastapi==0.109.0
uvicorn==0.27.0
EOF

cat > services/agent/app/main.py << 'EOF'
from fastapi import FastAPI
app = FastAPI(title="Patent Agent")

@app.get("/")
def root(): return {"message": "Agent Service"}

@app.get("/health")
def health(): return {"status": "healthy"}

@app.post("/runs")
def create_run(data: dict): return {"run_id": "123", "status": "queued"}

if __name__ == "__main__":
    import uvicorn
    uvicorn.run(app, host="0.0.0.0", port=8000)
EOF

# Create Docker Compose
cat > infra/docker/docker-compose.yml << 'EOF'
version: '3.8'
services:
  db:
    image: postgres:16
    environment:
      POSTGRES_USER: postgres
      POSTGRES_PASSWORD: postgres
      POSTGRES_DB: patentdb
    ports: ["5432:5432"]
  
  redis:
    image: redis:7-alpine
    ports: ["6379:6379"]
  
  minio:
    image: minio/minio
    ports: ["9000:9000", "9001:9001"]
    environment:
      MINIO_ROOT_USER: minioadmin
      MINIO_ROOT_PASSWORD: minioadmin
    command: server /data --console-address ":9001"
  
  web:
    image: node:20-alpine
    working_dir: /app
    volumes: ["./apps/web:/app"]
    ports: ["3000:3000"]
    command: sh -c "npm install && npm run dev"
    depends_on: [api]
  
  api:
    image: node:20-alpine
    working_dir: /app
    volumes: ["./apps/api:/app"]
    ports: ["3001:3001"]
    command: sh -c "npm install && npx ts-node src/main.ts"
    depends_on: [db]
  
  agent:
    image: python:3.11-slim
    working_dir: /app
    volumes: ["./services/agent:/app"]
    ports: ["8000:8000"]
    command: sh -c "pip install -r requirements.txt && python app/main.py"
EOF

echo "🐳 Starting Docker services..."
docker-compose -f infra/docker/docker-compose.yml up -d --build

echo ""
echo "✅ PLATFORM RUNNING!"
echo ""
echo "Web:   http://localhost:3000"
echo "API:   http://localhost:3001/api/docs"
echo "Agent: http://localhost:8000/docs"
echo ""
echo "Stop: docker-compose -f infra/docker/docker-compose.yml down"
